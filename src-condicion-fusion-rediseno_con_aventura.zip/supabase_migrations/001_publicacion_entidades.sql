-- ─────────────────────────────────────────────────────────────────────────
-- Migración: publicación de entidades para "Aventura" (feed público de DM)
-- ─────────────────────────────────────────────────────────────────────────
-- Añade a cada tabla de entidad del editor de mundo:
--   publicado     boolean       — visible para jugadores en /garlia/aventura
--   publicado_at  timestamptz   — momento de publicación (orden del feed)
--
-- Ejecutar en el SQL Editor de Supabase. Es idempotente (usa IF NOT EXISTS).

alter table public.personajes  add column if not exists publicado boolean not null default false;
alter table public.personajes  add column if not exists publicado_at timestamptz;

alter table public.criaturas   add column if not exists publicado boolean not null default false;
alter table public.criaturas   add column if not exists publicado_at timestamptz;

alter table public.items       add column if not exists publicado boolean not null default false;
alter table public.items       add column if not exists publicado_at timestamptz;

alter table public.reinos      add column if not exists publicado boolean not null default false;
alter table public.reinos      add column if not exists publicado_at timestamptz;

alter table public.ciudades    add column if not exists publicado boolean not null default false;
alter table public.ciudades    add column if not exists publicado_at timestamptz;

alter table public.hechizos    add column if not exists publicado boolean not null default false;
alter table public.hechizos    add column if not exists publicado_at timestamptz;

alter table public.dones       add column if not exists publicado boolean not null default false;
alter table public.dones       add column if not exists publicado_at timestamptz;

alter table public.runas       add column if not exists publicado boolean not null default false;
alter table public.runas       add column if not exists publicado_at timestamptz;

-- Índices para que el feed público (ORDER BY publicado_at DESC WHERE publicado) sea rápido
create index if not exists idx_personajes_publicado on public.personajes (publicado, publicado_at desc);
create index if not exists idx_criaturas_publicado   on public.criaturas  (publicado, publicado_at desc);
create index if not exists idx_items_publicado       on public.items     (publicado, publicado_at desc);
create index if not exists idx_reinos_publicado      on public.reinos    (publicado, publicado_at desc);
create index if not exists idx_ciudades_publicado    on public.ciudades  (publicado, publicado_at desc);
create index if not exists idx_hechizos_publicado    on public.hechizos  (publicado, publicado_at desc);
create index if not exists idx_dones_publicado       on public.dones     (publicado, publicado_at desc);
create index if not exists idx_runas_publicado       on public.runas     (publicado, publicado_at desc);

-- RLS: si las tablas ya tienen políticas públicas de lectura, esto no es
-- necesario. Si tus tablas están abiertas solo a usuarios autenticados y
-- quieres que /garlia/aventura sea visible sin login, añade políticas como:
--
-- create policy "Lectura publica de publicados" on public.criaturas
--   for select using (publicado = true);
--
-- (repetir por tabla, ajustando a tu esquema de auth actual)
